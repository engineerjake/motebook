package com.motebook;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public class MoteBookMod implements ModInitializer {

    @Override
    public void onInitialize() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            // Only run on the server side
            if (world.method_8608()) return class_1269.field_5811;

            // Only trigger when right-clicking a player
            if (!(entity instanceof class_1657 targetPlayer)) return class_1269.field_5811;

            // Only trigger when holding a Book and Quill in the main hand
            class_1799 heldItem = player.method_5998(hand);
            if (hand != class_1268.field_5808 || !heldItem.method_31574(class_1802.field_8674)) return class_1269.field_5811;

            String username = targetPlayer.method_5477().getString();
            
            // Log the interaction
            player.method_7353(
                class_2561.method_43470("§aRight-clicked player: §e" + username), 
                false
            );

            return class_1269.field_5812;
        });
        
        LOGGER.info("Mote Book Mod initialized!");
    }
    
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("mote-book");
}